import React, { useState } from 'react';
import { Button, FlatList, StyleSheet, Text, TextInput, View } from 'react-native';

const App = () => {
  const [amount, setAmount] = useState('');
  const [denominations, setDenominations] = useState([]);

  const calculateDenominations = (amount) => {
    const notes = [50, 20, 10];
    let remainingAmount = parseInt(amount, 10);
    const result = [];

    for (let note of notes) {
      if (remainingAmount >= note) {
        const count = Math.floor(remainingAmount / note);
        result.push({ note, count });
        remainingAmount -= count * note;
      }
    }

    return result;
  };

  const handleCalculate = () => {
    if (amount && amount % 10 === 0) {
      const result = calculateDenominations(amount);
      setDenominations(result);
    } else {
      alert('O valor deve ser um múltiplo de 10.');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Digite o valor a ser retirado(múltiplo de 10): </Text>
      <TextInput
        style={styles.input}
        placeholder="Digite o valor de retirada"
        keyboardType="numeric"
        value={amount}
        onChangeText={setAmount}
      />
      <Button title="Calcular retirada" onPress={handleCalculate} />
      <FlatList
        data={denominations}
        keyExtractor={(item) => item.note.toString()}
        renderItem={({ item }) => (
          <View style={styles.item}>
            <Text style={styles.text}> R${item.note}: {item.count} cédula(s)</Text>
          </View>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 80,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 30,
    textAlign: 'center',
    color: 'gray',
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 16,
    paddingHorizontal: 8,
    fontSize: 18,
  },
  item: {
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
  },
  text: {
    fontSize: 18,
  },
});

export default App;
